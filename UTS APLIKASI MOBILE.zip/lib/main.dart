import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jaya Electronics Store',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: TextTheme(
          headline1: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
          bodyText1: TextStyle(fontSize: 16.0),
        ),
      ),
      home: HomePage(),
      routes: {
        '/login': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),
        '/electronicsStore': (context) => ElectronicsStorePage(),
        '/search': (context) => SearchPage(),
      },
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Jaya Electronics Store'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.network(
                'https://vectorified.com/images/hp-icon-1.png',
                height: 150,
              ),
              SizedBox(height: 20),
              Text(
                'Welcome to Jaya Electronics Store',
                style: Theme.of(context).textTheme.headline1,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/login');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      Color(0xffcf92dd), // Ganti warna tombol Login
                ),
                child: Text('Login'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/register');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      Color(0xff71dcd8), // Ganti warna tombol Daftar
                ),
                child: Text('Register'),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Username',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Password',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Aksi setelah login berhasil
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ElectronicsStorePage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xff55e488), // Ganti warna tombol Login
              ),
              child: Text('Login'),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Nama',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(
                hintText: 'Username',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Password',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Aksi setelah registrasi berhasil
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ElectronicsStorePage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xff7bda50), // Ganti warna tombol Daftar
              ),
              child: Text('Daftar'),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class ElectronicsStorePage extends StatefulWidget {
  @override
  _ElectronicsStorePageState createState() => _ElectronicsStorePageState();
}

class _ElectronicsStorePageState extends State<ElectronicsStorePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Jaya Electronics Store'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // Fitur Pencarian
            TextField(
              decoration: InputDecoration(
                hintText: 'Cari Produk Elektronik...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              onTap: () {
                Navigator.pushNamed(context, '/search');
              },
            ),
            SizedBox(height: 20),
            Text(
              'Rekomendasi Produk',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Column(
                  children: [
                    Image.network(
                      'https://png.pngtree.com/background/20230527/original/pngtree-laptop-computer-with-glowing-lights-on-it-picture-image_2760953.jpg',
                      width: 50,
                      height: 50,
                    ),
                    Text('Laptop'),
                  ],
                ),
                Column(
                  children: [
                    Image.network(
                      'https://m.media-amazon.com/images/I/613T4Ak9a7L._AC_SL1500_.jpg',
                      width: 50,
                      height: 50,
                    ),
                    Text('Smartphone'),
                  ],
                ),
                Column(
                  children: [
                    Image.network(
                      'https://images.news18.com/ibnlive/uploads/2022/09/lenovo-m10-plus-166445365516x9.jpg',
                      width: 50,
                      height: 50,
                    ),
                    Text('Tablet'),
                  ],
                ),
                Column(
                  children: [
                    Image.network(
                      'https://tse1.mm.bing.net/th?id=OIP.GDrVei9iPypueT_uGoWBFgHaGj&pid=Api&P=0&h=220',
                      width: 50,
                      height: 50,
                    ),
                    Text('Kamera'),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              'Daftar Produk',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            ListTile(
              leading: Image.network(
                'https://tse3.mm.bing.net/th?id=OIP.-XjMHWLk4veln9eEQD0I2wHaFJ&pid=Api&P=0&h=2200',
                width: 50,
                height: 50,
              ),
              title: Text('Laptop Dell Inspiron'),
              subtitle: Text('Rp 8.000.000'),
              trailing: Icon(Icons.shopping_cart),
            ),
            ListTile(
              leading: Image.network(
                'https://tse4.mm.bing.net/th?id=OIP.OhLeqsDb8cC76IbsK_z3SwHaJ4&pid=Api&P=0&h=220',
                width: 50,
                height: 50,
              ),
              title: Text('Smartphone Samsung Galaxy S21'),
              subtitle: Text('Rp 12.000.000'),
              trailing: Icon(Icons.shopping_cart),
            ),
            ListTile(
              leading: Image.network(
                'https://images-na.ssl-images-amazon.com/images/I/71B-5ZUUl3L._AC_SL1500_.jpg',
                width: 50,
                height: 50,
              ),
              title: Text('Tablet Lenovo'),
              subtitle: Text('Rp 3.500.000'),
              trailing: Icon(Icons.shopping_cart),
            ),
            // Add more products as needed
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class SearchPage extends StatelessWidget {
  final List<Map<String, String>> sampleResults = [
    {
      'name': 'Laptop Dell Inspiron',
      'image':
          'https://tse3.mm.bing.net/th?id=OIP.-XjMHWLk4veln9eEQD0I2wHaFJ&pid=Api&P=0&h=2200',
    },
    {
      'name': 'Smartphone Samsung Galaxy S21',
      'image':
          'https://tse4.mm.bing.net/th?id=OIP.OhLeqsDb8cC76IbsK_z3SwHaJ4&pid=Api&P=0&h=220',
    },
    {
      'name': 'Tablet Lenovo',
      'image':
          'https://images-na.ssl-images-amazon.com/images/I/71B-5ZUUl3L._AC_SL1500_.jpg',
    },
    {
      'name': 'Kamera Canon EOS',
      'image':
          'https://tse2.mm.bing.net/th?id=OIP.OO4YuzeGT3YEoeisp3jn4AHaFo&pid=Api&P=0&h=220', // Replace with actual image URL
    },
    {
      'name': 'Smartphone Xiaomi Redmi Note',
      'image':
          'https://i5.walmartimages.com/asr/b226a7f9-789f-4bc4-80bb-80a734a5d047_1.16641dd14d37602ed08758db6f212790.jpeg', // Replace with actual image URL
    },
    {
      'name': 'Laptop HP Pavilion',
      'image':
          'https://tse3.mm.bing.net/th?id=OIP.V8-jfN8o1iCFqgsPdnhgJwHaGR&pid=Api&P=0&h=220', // Replace with actual image URL
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hasil Pencarian'),
      ),
      body: ListView.builder(
        itemCount: sampleResults.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Image.network(
              sampleResults[index]['image']!,
              width: 50,
              height: 50,
            ),
            title: Text(sampleResults[index]['name']!),
            onTap: () {
              // Implement product details navigation or action here
            },
          );
        },
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class BottomNavBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.search),
          label: 'Search',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.shopping_cart),
          label: 'Cart',
        ),
      ],
      currentIndex: 0,
      onTap: (index) {
        // Handle navigation based on index
        if (index == 0) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomePage()),
          );
        } else if (index == 1) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => SearchPage()),
          );
        } else if (index == 2) {
          // Navigate to Cart page (not implemented in this example)
        }
      },
    );
  }
}
